pkg update

pkg install git

pkg install python

pkg install python-pip

git clone https://github.com/kaijo-coder/iancpm.git

cd iancpm

git pull

pip install -r requirements.txt

python main.py
